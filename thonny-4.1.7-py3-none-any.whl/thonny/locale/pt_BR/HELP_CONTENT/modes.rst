Modos diferentes
================

*Ferramentas → Opções → Geral* permite alternar a interface de usuário do Thonny para um dos três modos disponíveis.

Modo normal
-----------

Este é o modo padrão. Nada muito a dizer sobre isso.

Modo simples
------------

Neste modo, os menus ficam ocultos e os botões da barra de ferramentas têm legendas. Use um pequeno link no canto superior direito da janela principal para retornar ao modo normal.

Modo especialista
-----------------

Este modo se parece quase com o modo normal, mas possui alguns recursos extras, que são úteis para professores.

* O menu Exibir ganha um item extra *Tela cheia* que coloca Thonny em tela cheia.
* Clicar duas vezes na guia de um editor ou exibição maximiza esse editor ou exibição. Desmaximize teclando ESC.
* O menu Ferramentas recebe um item extra *Abrir repetidor...* que permite repetir os logs de ação do usuário.

